import { create } from "venom-bot";
import cluster from "cluster";
import process from "process";
import chalk from "chalk";
import fs from "fs";

if (cluster.isPrimary) {
  console.info(`Primary cluster: ${process.pid}`);

  cluster.fork();
  // cluster.fork();
  // cluster.fork();
  // cluster.fork();

  cluster.addListener("exit", function (worker) {
    console.info(`Worker ${worker.id} is exited`);
    cluster.fork();
  });
} else {
  // const data_tour = fs.readFileSync("./text/tour.txt");
  const data_travel = fs.readFileSync("./text/travel.txt");
  // const data_ticket = fs.readFileSync("./text/ticketing.txt");

  create({
    session: `iqbaladudu`,
  }).then((client) => {
    client.onMessage(async (msg) => {
      if (msg.chat.labels[0] == "3") {
        await client
          .sendText(msg.from, `${data_travel}`)
          .then(() =>
            console.log(
              `Sukses mengirim pesan ke grup ${chalk.bgGreen(
                msg.chat.name
              )} dari worker #${cluster.worker.id}`
            )
          )
          .catch((erro) => console.log(erro));
        // await client
        //   .sendText(msg.from, `${data_tour}`)
        //   .then(() =>
        //     console.log(
        //       `Sukses mengirim pesan ke grup ${chalk.bgGreen(
        //         msg.chat.name
        //       )} dari worker #${cluster.worker.id}`
        //     )
        //   );
        // await client
        //   .sendText(msg.from, `${data_ticket}`)
        //   .then(() =>
        //     console.log(
        //       `Sukses mengirim pesan ke grup ${chalk.bgGreen(
        //         msg.chat.name
        //       )} dari worker #${cluster.worker.id}`
        //     )
        //   );
      }
    });
  });
}
