#!/bin/bash

condition=true

while "${condition}"; do
echo "Memulai bot..."
echo

# run node js script
node index.mjs
sleep 1s; done
