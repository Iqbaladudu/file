const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require("fs")
const { MessageMedia } = require('whatsapp-web.js');

const data_tour = fs.readFileSync("./text/tour.txt");
const data_services = fs.readFileSync("./text/services.txt");

const client = new Client({
    authStrategy: new LocalAuth()
});

client.on('qr', (qr) => {
    // Generate and scan this code with your phone
    console.log('QR RECEIVED', qr);
    qrcode.generate(qr, { small: true})
});

client.on('ready', () => {
    console.log('Client is ready!');
});

 client.on('message', async msg => {
    const isGroup = await msg.getChat().then((chat) => chat.isGroup).then((isGroup) => {
        return isGroup
    })
    
    if (isGroup == true) {
        const groupName = await msg.getChat().then((chat) => chat.name).then((name) => {
            return name
        })

        const labelId = await msg.getChat()?.then((chat) => chat.getLabels()?.then((label) => label[0]?.id)).then((id) => {
            return id
        })

        function getRndInteger() {
            return Math.floor(Math.random() * 4 ) + 1;
          }
            
        // if (labelId == 1 || labelId == labelId == getRndInteger()) {
        //     client.sendMessage(msg.from, `${data_ticket}`).then(() => {
        //         console.log(
        //             `Sukses mengirim pesan ke grup ${groupName}`
        //           )
        //     })
        // }

        if (labelId == 1 || labelId == getRndInteger()) {
            client.sendMessage(msg.from, `${data_tour}`).then(() => {
                console.log(
                    `Sukses mengirim pesan ke grup ${groupName}`
                  )
            })
        }

        if (labelId == 1 || labelId == getRndInteger()) {
            client.sendMessage(msg.from, `${data_services}`).then(() => {
                console.log(
                    `Sukses mengirim pesan ke grup ${groupName}`
                  )
            })
        }
    }
});

client.initialize();